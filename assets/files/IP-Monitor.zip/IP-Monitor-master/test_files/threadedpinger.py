import queue
import os
import subprocess
import re
import threading
import time
from tkinter import *
from tkinter import ttk



class GUI:

    def __init__(self):
        pass

    def pingBranches():
        pass

    # parse the txt logs for ping results
    # set this on a scheduler using import sched
    def checkResults():
        pass


# write ping results to txt files and process in gui
class ThreadedTask:

    def __init__(self):
        pass

    def run():
        pass
