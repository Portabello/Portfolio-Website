# IP-Monitor
This program monitored the network status of user inputted IP addresses WAN connection, routers, and VPN tunnel. It logged latency and generated analysis and statistics for each location. This project was completed using Python and the TKinter library.

![alt text](https://github.com/Portabello/IP-Monitor/blob/master/test_files/ipmonitor.png)
