# Breakout
game of breakout developed in javascript using THREE.js library

hit detection on player block needs to be improved. 

ball sometimes bounces underneath player and between bottom box and gets caught in weird rotations.

