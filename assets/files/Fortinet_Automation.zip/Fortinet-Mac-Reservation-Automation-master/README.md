# Fortinet-Mac-Reservation-Automation
Automates the process of making MAC address based IP reservations in a Fortinet 60E Router and Fortimanager using Python, Paramiko (a python module used for ssh connections), and the Fortinet CLI

![alt text](https://github.com/Portabello/Fortinet-Mac-Reservation-Automation/blob/master/fortinet_mac_reservation_automation%20screenshot.png)
