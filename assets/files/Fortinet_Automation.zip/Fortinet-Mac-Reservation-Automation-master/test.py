# Implement a way to automate teh MAC Address reservation process in out Fortinet 60E Routers and Fortimanager
# using python and the paramiko library and possibly tk later on

#this is a module used for SSH2 connections
import paramiko
import time

# executes command passed in input to server passed in input
# prints server command line output to screen
def execute_command(server, command):
    stdin, stdout, stderr = server.exec_command(command)
    #time.sleep(3)
    for x in stdout:
        print(stdout.readline())


def get_reserved_address_list(server):
    command = """config system dhcp server
                 edit 1
                 config reserved-address
                 sh
              """
    stdin, stdout, stderr = ssh.exec_command(command)
    file = open('temp-reserved-address.txt', "w")
    for x in stdout:
        file.write(stdout.readline())
        #print(stdout.readline())

def parse_output(output):
    pass



ssh = paramiko.SSHClient()

ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

ssh.connect('12.97.210.122', username = '*****', password = '*****')

get_reserved_address_list(ssh)

#stdin, stdout, stderr = ssh.exec_command('config system dhcp server')




#sleep(5)

#execute_command(ssh, 'sh')

ssh.close()






#raw_input()
