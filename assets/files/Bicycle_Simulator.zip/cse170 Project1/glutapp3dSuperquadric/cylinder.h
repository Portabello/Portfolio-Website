//cylinder class
//this class creates a cylinder with specified length and radius
# pragma once

void drawCylinder(double length, double radius);