FREEGLUTAPP
-----------

This is a demo project to start implementing OpenGL applications
using freeglut and glew. 

Linux:
 - Type make to compile the application (NOT TESTED YET!!)
 - The makefile will compile all .cpp files in the folder
 - Edit the makefile to change the name of the executable

Windows:
 - Use the visual studio 10 solution in the visualc10 folder
 - Make sure visualc 2010 is installed 
 - To open the project just double click the .sln file

Note:
 - the provided freeglut library is only used in Windows; 
   in Linux the compiler will seek for the header files and 
   libraries in the default development folders
   




