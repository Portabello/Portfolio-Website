# pragma once

class Vect {
public:
	double x;
	double y;
	double z;

	Vect() {
		x = 0.0; 
		y = 0.0; 
		z = 0.0;
	}
	
	double distance(Vect v) {
		double dist = (x - v.x)*(x - v.x) + (z - v.z)*(z - v.z);
		return dist;
	}
};

//function to load texture
GLuint loadTexture(char* file);
//function to set color for object
void setColor(float r, float g, float b, float a);
//function to return time
double getTime();