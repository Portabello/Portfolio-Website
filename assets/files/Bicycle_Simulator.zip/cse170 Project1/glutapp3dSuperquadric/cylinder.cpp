# include <math.h>
# include <stdio.h>
# include <iostream>
# include <fstream>
# include "app_window.h"
# include "texture.h"
# include "cylinder.h"
//this function draws a cylinder using the given parameters of length and radius
void drawCylinder(double length, double radius) {
	glShadeModel(GL_SMOOTH);
	for (int i = 0; i < 10; i++) {

		double angle = (double)i / 10 * 2 * 3.14159265;
		double angle2 = (double)(i + 1) / 10 * 2 * 3.14159265;
		double cosAngle = cos(angle);
		double sinAngle = sin(angle);
		double cosAngle2 = cos(angle2);
		double sinAngle2 = sin(angle2);

		//draws the top of the cylinder part
		glBegin(GL_POLYGON);
			glNormal3d(0, 1, 0);
			glVertex3d(0, length / 2, 0);
			glNormal3d(0, 1, 0);
			glVertex3d(radius*cosAngle2, length / 2, radius*sinAngle2);
			glNormal3d(0, 1, 0);
			glVertex3d(radius*cosAngle, length / 2, radius*sinAngle);
		glEnd();

		//draws the side of the cylinder part
		glBegin(GL_POLYGON);
			glNormal3d(cosAngle2, 0, sinAngle2);
			glVertex3d(radius*cosAngle2, length / 2, radius*sinAngle2);
			glNormal3d(cosAngle2, 0, sinAngle2);
			glVertex3d(radius*cosAngle2, -length / 2, radius*sinAngle2);
			glNormal3d(cosAngle, 0, sinAngle);
			glVertex3d(radius*cosAngle, -length / 2, radius*sinAngle);
			glNormal3d(cosAngle, 0, sinAngle);
			glVertex3d(radius*cosAngle, length / 2, radius*sinAngle);
		glEnd();

		//draws the bottom of the cylinder part
		glBegin(GL_POLYGON);
			glNormal3d(0, -1, 0);
			glVertex3d(0, -length / 2, 0);
			glNormal3d(0, -1, 0);
			glVertex3d(radius*cosAngle, -length / 2, radius*sinAngle);
			glNormal3d(0, -1, 0);
			glVertex3d(radius*cosAngle2, -length / 2, radius*sinAngle2);
		glEnd();
	}
}