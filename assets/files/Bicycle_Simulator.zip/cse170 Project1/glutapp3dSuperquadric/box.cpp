# include <math.h>
# include <stdio.h>
# include <iostream>
# include <fstream>
# include "app_window.h"
# include "texture.h"
# include "box.h"

void drawBox(double x, double y, double z) {
	//front face
	glBegin(GL_POLYGON);
		glNormal3d(0, 0, -1);
		glVertex3d(x, -y, -z);
		glVertex3d(-x, -y, -z);
		glVertex3d(-x, y, -z);
		glVertex3d(x, y,  -z);
	glEnd();

	//back face
	glBegin(GL_POLYGON);
		glNormal3d(0, 0, 1);
		glVertex3d(x, -y, z);
		glVertex3d(-x, -y, z);
		glVertex3d(-x, y, z);
		glVertex3d(x, y, z);
	glEnd();

	//left face
	glBegin(GL_POLYGON);
		glNormal3d(1, 0, 0);
		glVertex3d(x, -y, z);
		glVertex3d(x, -y, -z);
		glVertex3d(x, y, -z);
		glVertex3d(x, y, z);
	glEnd();

	//right face
	glBegin(GL_POLYGON);
	glNormal3d(-1, 0, 0);
		glVertex3d(-x, -y, z);
		glVertex3d(-x, -y, -z);
		glVertex3d(-x, y, -z);
		glVertex3d(-x, y, z);
	glEnd();

	//top face
	glBegin(GL_POLYGON);
	glNormal3d(0, 1, 0);
		glVertex3d(x, y, -z);
		glVertex3d(-x, y, -z);
		glVertex3d(-x, y, z);
		glVertex3d(x, y, z);
	glEnd();

	//bottom face
	glBegin(GL_POLYGON);
	glNormal3d(0, -1, 0);
		glVertex3d(x, -y, -z);
		glVertex3d(-x, -y, -z);
		glVertex3d(-x, -y, z);
		glVertex3d(x, -y, z);
	glEnd();
}