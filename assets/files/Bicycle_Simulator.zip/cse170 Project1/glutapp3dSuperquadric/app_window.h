# include <gsim/gs.h>
# include <gsim/gs_color.h>
# include <gsim/gs_array.h>
# include <gsim/gs_light.h>
# include <gsim/gs_vec.h>
# include <freeglut.h>

struct App {
	double fovy;
	bool   viewaxis;
	double rotx, roty;
};
extern App* app; 

void appKeyboardFunc(unsigned char key, int x, int y);
void appKeyboardFunc(int key, int x, int y);
void appDrawScene();
void appResizeWindow(int w, int h);
