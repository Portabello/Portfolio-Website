//box class
//this class will draw a box with the given parameters of width height and depth
# pragma once

void drawBox(double x, double y, double z);