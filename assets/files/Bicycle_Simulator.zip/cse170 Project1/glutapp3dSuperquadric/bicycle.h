# include "texture.h"
# include "cylinder.h"
# include "box.h"

//class
class Bicycle {
public:
	double frontWheel;
	double backWheel;
	double pedal;
	double rot;
	double turnAngle;
	double speed;
	Vect location;
	double getX();
	double getY();
	double getZ();

	Bicycle() {
		rot = 0;
		turnAngle = 0;
		speed = 0;
		location.y = 8;
		frontWheel = 0;
		backWheel = 0;
		pedal = 0;
	}
};

//functions
void update(Bicycle *bicycle);
void drawBicycle(Bicycle *bicycle);
void wheel();
void frame();
void fork();
void pedals(double angle);
void handles();
void seat();
double minmax(double x, double min, double max);

